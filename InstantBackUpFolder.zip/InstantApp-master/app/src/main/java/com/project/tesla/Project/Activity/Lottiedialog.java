package com.project.tesla.Project.Activity;

public class Lottiedialog {
    public Lottiedialog(ChatActivity chatActivity) {
    }
}
