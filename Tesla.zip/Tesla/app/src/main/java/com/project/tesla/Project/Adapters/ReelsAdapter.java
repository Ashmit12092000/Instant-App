package com.project.tesla.Project.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.provider.ContactsContract;
import android.view.*;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;
import com.allattentionhere.autoplayvideos.AAH_CustomViewHolder;
import com.allattentionhere.autoplayvideos.AAH_VideosAdapter;
import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;
import com.project.tesla.Project.Activity.UserProfileActivity;
import com.project.tesla.Project.CustomClasses.CustomVideoView;
import com.project.tesla.Project.Model.Post;

import com.project.tesla.R;
import org.jetbrains.annotations.NotNull;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ReelsAdapter extends RecyclerView.Adapter<ReelsAdapter.MyViewHolder> {
    Context context;
    List<Post>  videoList;
    public ReelsAdapter(Context context, List<Post> videoList) {
        this.context = context;
        this.videoList = videoList;
    }
    @NonNull
    @NotNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.reels_layout, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull MyViewHolder holder, int position) {
        holder.setData(videoList.get(position));
    }

    @Override
    public int getItemCount() {
        return videoList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView reelsLikeBtn;
        ImageView reelsComments;
        ImageView audio;
        ImageView reelShare;
        ImageView imgPlayback;
        TextView reelsUsername;
        LottieAnimationView heartAnimation;
        CircleImageView reelsUserProfilePhoto;
        VideoView videoView;
        ProgressBar progressBar;
        TextView reelsCaption;
        Boolean isMuted=false;
        MediaPlayer mediaPlayer;
        String name;

        int stopPosition;
        public MyViewHolder(View x) {
            super(x);
            reelsLikeBtn=x.findViewById(R.id.reels_like_btn);
            reelsComments=x.findViewById(R.id.reels_comment);
            audio=x.findViewById(R.id.audio);
            reelShare=x.findViewById(R.id.reels_share);
            reelsUsername=x.findViewById(R.id.reels_username);
            heartAnimation=x.findViewById(R.id.heart_animation);
            reelsUserProfilePhoto=x.findViewById(R.id.reels_user_profile_photo);
            videoView=x.findViewById(R.id.videoView);
            progressBar=x.findViewById(R.id.progressBar);
            imgPlayback=x.findViewById(R.id.img_playback);
            reelsCaption=x.findViewById(R.id.reels_Caption);

        }
        @SuppressLint("ClickableViewAccessibility")
        void setData(Post post){
            videoView.setVideoPath(post.getVideo_url());
            reelsCaption.setText(post.getCaption_txt());

            FirebaseDatabase.getInstance()
                    .getReference()
                    .child("users")
                    .child(post.getUid())
                    .addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                            if(snapshot.exists()){
                                name=snapshot.child("name").getValue(String.class);
                                String image_uri=snapshot.child("profile_image").getValue(String.class);
                                Glide.with(context).load(image_uri).placeholder(R.drawable.user).into(reelsUserProfilePhoto);
                                reelsUsername.setText(name);
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull @NotNull DatabaseError error) {

                        }
                    });
                    reelsUsername.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent =new Intent(context, UserProfileActivity.class);
                            intent.putExtra("uid",post.getUid());
                            context.startActivity(intent);
                        }
                    });
                    reelsUserProfilePhoto.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent =new Intent(context, UserProfileActivity.class);
                            intent.putExtra("uid",post.getUid());
                            context.startActivity(intent);
                        }
                    });

            videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mediaPlayer=mp;
                    progressBar.setVisibility(View.GONE);
                    mp.start();
                }
            });
            getlikedStatus(post.getVid());
            nrlikes(post.getVid());
            reelsLikeBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(reelsLikeBtn.getTag().equals("not_liked")){
                        FirebaseDatabase.getInstance().getReference().child("likes").child(post.getVid())
                                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                .setValue(true);
                    }
                    else{
                        FirebaseDatabase.getInstance().getReference().child("likes").child(post.getVid())
                                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                .removeValue();
                    }
                }
            });
            audio.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(isMuted){
                        audio.setImageResource(R.drawable.ic_unmute);
                        mediaPlayer.setVolume(1f,1f);
                        isMuted=false;
                    }
                    else{
                        audio.setImageResource(R.drawable.ic_mute);
                        mediaPlayer.setVolume(0f,0f);
                        isMuted=true;
                    }
                }
            });

            videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mp.start();
                }
            });
            videoView.setOnTouchListener(new View.OnTouchListener() {
                private GestureDetector gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onDoubleTap(MotionEvent e) {
                        heartAnimation.setVisibility(View.GONE);
                        if(reelsLikeBtn.getTag().equals("not_liked")){
                            heartAnimation.setVisibility(View.VISIBLE);
                            heartAnimation.playAnimation();
                            FirebaseDatabase.getInstance().getReference().child("likes").child(post.getVid())
                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                    .setValue(true);
                        }
                        else{
                            heartAnimation.setVisibility(View.GONE);
                            videoView.clearAnimation();
                            FirebaseDatabase.getInstance().getReference().child("likes").child(post.getVid())
                                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                    .removeValue();
                        }
                        return super.onDoubleTap(e);
                    }
                    @Override
                    public boolean onSingleTapConfirmed(MotionEvent event) {
                        try {
                            if (mediaPlayer.isPlaying()) {
                                mediaPlayer.pause();
                                imgPlayback.setVisibility(View.VISIBLE);
                            } else {
                                mediaPlayer.start();
                                imgPlayback.setVisibility(View.GONE);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        return false;
                    }
                });
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    gestureDetector.onTouchEvent(event);
                    return true;
                }
            });
        }



        private void getlikedStatus(String vid) {
            final FirebaseUser firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
            DatabaseReference likeref=FirebaseDatabase.getInstance().getReference("likes").child(vid);
            likeref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if(snapshot.child(firebaseUser.getUid()).exists()) {

                        reelsLikeBtn.setImageResource(R.drawable.ic_heart);
                        reelsLikeBtn.setTag("liked");
                    }
                    else{

                        reelsLikeBtn.setImageResource(R.drawable.ic_unlike);
                        reelsLikeBtn.setTag("not_liked");
                    }

                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }
        private void nrlikes(String vid) {
            DatabaseReference likesref=FirebaseDatabase.getInstance().getReference().child("likes")
                    .child(vid);
            likesref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    int likescount=(int)snapshot.getChildrenCount();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }
    }
}
